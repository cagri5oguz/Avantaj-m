AVANTAJIM PWA - ilk deneme sürümü

Dosyaları HTTPS destekli statik web barındırma servisine yükleyin.
index.html, app.js, manifest.webmanifest, icon.svg ve sw.js aynı dizinde kalmalıdır.
Chrome ile yayımlanan HTTPS adresini açıp menüden 'Ana ekrana ekle' seçin.

Kampanyalar Supabase RPC get_personalized_offers üzerinden alınır. RLS etkin olmalıdır.
Sadece publishable key kullanılmıştır; service_role anahtarı kesinlikle eklenmemelidir.
Seçilen kart ve üyelik kimlikleri bu cihazın localStorage alanında tutulur.
Bu sürüm konum bildirimleri ve hesap senkronizasyonu içermez.

Not: Bazı Android tarayıcılarında tam PWA yükleme deneyimi için PNG 192x192 ve 512x512 ikonlar gerekebilir.
